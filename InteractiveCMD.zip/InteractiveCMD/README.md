Interactive CMD Shell
====================

Description
--------------------
This program is a sample to connect to cmd.exe (or any other program) using standard Input/Output. 

Prerequisites
-----------------

* .Net Framework 2.0.

* make.exe,mkdir.exe ( Cygwin or Mingw )

* nuget.exe


Compile 
-------

* Download nuget and install Microsoft.Net.Compilers using folowing command : 
```
nuget.exe install Microsoft.Net.Compilers
```
or just run 
```
make prerequests
```
* Put Microsoft.Net.Compilers.x.x.x folder in src path 
* Run make in ```src\``` path 
* .exe file will be in ```src\debug``` 
* enjoy! ;-) 

Usage
------

* Execute ```src\debug\InteractiveCMD.exe``` 

License
-------
This project is licensed under the GNU GENERAL PUBLIC LICENSE - see the [LICENSE.md](LICENSE.md) file for more details