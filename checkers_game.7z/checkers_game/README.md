# Board Game Using SFML and C++ (Simple Checkers)

# Build

To build this project run the following command in linux or mac: 
```
$ mkdir build
$ cd build
$ cmake .. 
```

# Run
to run project run the following command in terminal: 
```
$ make
```


