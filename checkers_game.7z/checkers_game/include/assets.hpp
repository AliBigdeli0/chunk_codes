#pragma once
#include <SFML/Graphics.hpp>

class Assets
{
public:
    static void LoadBackground(sf::Texture *, sf::Sprite *);
};
